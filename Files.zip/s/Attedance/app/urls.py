
from django.urls import path
from . import views
from app import views

urlpatterns = [
    path('home', views.home, name='homepage'), 
    path('attendance_list', views.attendance_list, name='attendance_list'),

      # This maps the base path to `home` view

    path('add_student/', views.add_student, name='add_student'),
    path('students/', views.student_list, name='students'),
]
